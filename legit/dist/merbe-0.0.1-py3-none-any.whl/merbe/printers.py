
class ConsoleLogger:

    def legit_print(self, text = None):
        print("Merbe - This is the official and verified package.")
        if text is not None:
            print(text)

# dependency-confusion.security
A package for a demo of Dependency Confusion Attack in Supply Chains for Security module
